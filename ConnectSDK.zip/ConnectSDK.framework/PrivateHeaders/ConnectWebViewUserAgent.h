
#import <Foundation/Foundation.h>

@interface ConnectWebViewUserAgent : NSObject

+ (NSString *)userAgentString;

@end
